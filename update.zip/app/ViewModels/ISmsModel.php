<?php 
namespace App\ViewModels;

interface ISmsModel 
{
    public function initialize($data);
}