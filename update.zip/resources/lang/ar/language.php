<?php

return array (
  'Attach File' => 'إرفاق ملف',
  'Delivered' => 'تسليم',
  'Delivery' => 'تسليم',
  'Developed' => 'المتقدمه النمو',
  'Do not have an account?' => 'ليس لديك حساب؟',
  'Expense' => 'حساب',
  'Expense Category' => 'فئة المصروفات',
  'File Link' => 'رابط الملف',
  'For Digital product sale_unit will be n/a' => 'بالنسبة للمنتجات الرقمية ، ستكون sale_unit غير متوفرة',
  'Forgot Password?' => 'نسيت كلمة المرور؟',
  'Gift Card' => 'بطاقة هدايا',
  'In Words' => 'بالكلمات',
  'Register' => 'سجل',
  'Signature' => 'توقيع',
  'Stamp' => 'طابع',
  'sale amount' => 'المبيعات',
);
