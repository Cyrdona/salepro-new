<?php

return array (
  'min' => 
  array (
    'file' => '',
  ),
);
