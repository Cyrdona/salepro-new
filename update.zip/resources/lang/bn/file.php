<?php

return array (
  'dashboard' => 'ড্যাশবোর্ড',
);
