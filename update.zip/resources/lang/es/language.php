<?php

return array (
  'Cash Flow' => 'Flujo de efectivo',
  'Cash in Hand' => 'Efectivo en mano',
);
