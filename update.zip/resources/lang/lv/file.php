<?php

return array (
  'Dashboard' => 'Mērinstrumentu panelis',
);
