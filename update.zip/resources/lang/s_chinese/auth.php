<?php

return array (
  'failed' => 'asfsafd',
  'throttle' => 'sdfsdf',
);
